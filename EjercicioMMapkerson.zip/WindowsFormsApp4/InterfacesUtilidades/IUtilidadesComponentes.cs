﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MacMapkerson.InterfacesUtilidades
{
    public interface IUtilidadesComponentes
    {
    }
}
